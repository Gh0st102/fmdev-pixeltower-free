fx_version 'adamant'
games { 'gta5' }

this_is_a_map 'yes'

data_file 'DLC_ITYP_REQUEST' 'stream/Dirt Roads/cityhills_02_metadata_024_strm.ytyp'
dependency '/assetpacks'